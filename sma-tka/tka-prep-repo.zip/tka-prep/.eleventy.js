const fs = require("fs");
const path = require("path");

module.exports = function (eleventyConfig) {
  // --- Shortcode: baca file CSS/JS mentah lalu suntikkan langsung ke halaman ---
  // Tujuan: hasil build (dist/**/*.html) TIDAK punya <link>/<script src> ke file
  // lain. Semua CSS & JS ikut ter-embed di dalam file HTML itu sendiri.
  eleventyConfig.addShortcode("inlineCSS", function (relPath) {
    const filePath = path.join(__dirname, "src", relPath);
    return fs.readFileSync(filePath, "utf8");
  });

  eleventyConfig.addShortcode("inlineJS", function (relPath) {
    const filePath = path.join(__dirname, "src", relPath);
    return fs.readFileSync(filePath, "utf8");
  });

  // --- Filter: ubah object/array JS jadi string JSON untuk di-embed ke <script> ---
  eleventyConfig.addFilter("dump", function (obj) {
    return JSON.stringify(obj);
  });

  eleventyConfig.addFilter("slugToTitle", function (slug) {
    if (!slug) return "";
    return slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  });

  eleventyConfig.addGlobalData("currentYear", new Date().getFullYear());

  // Daftar rumpun ilmu unik, dihitung sekali saat build dari pendukungProdi.json
  eleventyConfig.addGlobalData("rumpunUnik", function () {
    const data = JSON.parse(
      fs.readFileSync(path.join(__dirname, "src", "_data", "pendukungProdi.json"), "utf8")
    );
    return [...new Set(data.map((row) => row.rumpunIlmu))];
  });

  // Data & partial internal Eleventy (_data, _includes) TIDAK ikut di-passthrough
  // sebagai file terpisah ke dist/ -- hanya dibaca saat build lalu di-inline.

  return {
    dir: {
      input: "src",
      output: "dist",
      includes: "_includes",
      data: "_data",
    },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    templateFormats: ["njk", "md"],
  };
};
